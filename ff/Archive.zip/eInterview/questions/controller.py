def createQuestions(request):
    return "create quostion ap]i"

def listQuestions(request):
    return "this is question list"