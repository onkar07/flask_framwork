from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from utils.policy import requires_access_level
from eInterview.questions.controller import *

questions_bp = Blueprint('questions_bp',__name__, static_url_path='assets')



@questions_bp.route("/list", methods=['POST'])
@jwt_required()
@requires_access_level(access_level=['admin','teacher'])
def lists():
    return listQuestions(request)



@questions_bp.route("/create", methods=['POST'])
@jwt_required()
@requires_access_level(access_level=['admin','teacher'])
def create():
    return createQuestions(request)