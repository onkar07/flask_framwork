def subjectList(request):
    data=request.get_json()
    email=data.get('name')
    print("EMAIL",email)
    return "Renderd successfully "+email