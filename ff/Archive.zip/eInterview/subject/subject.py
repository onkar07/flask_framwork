from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from utils.policy import requires_access_level
from eInterview.subject.controller import *
subject_bp = Blueprint('subject_bp',__name__, static_url_path='assets')



@subject_bp.route("/list", methods=['POST'])
@jwt_required()
@requires_access_level(access_level=['admin','student'])
def lists():
    return subjectList(request)