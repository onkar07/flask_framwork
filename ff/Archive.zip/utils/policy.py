import pymysql
from functools import wraps
from flask import url_for, request, redirect, session, jsonify
from utils.sqlConnection import mysqlConnect
# from user import User

def requires_access_level(access_level):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            conn = mysqlConnect()
            nn = 'sudo'
            sql = 'select role from user where name=%s'
            cur = conn.cursor()
            cur.execute(sql,nn)
            output = cur.fetchall()
            role = output[0][0]
            conn.close()
            if role not in access_level:
                return jsonify({"msg": "permission denied"})
            else:
                return f(*args, **kwargs)
        return decorated_function
    return decorator



   