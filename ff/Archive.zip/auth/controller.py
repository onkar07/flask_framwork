from crypt import methods
from unicodedata import name
from flask import request, Blueprint, jsonify
from werkzeug.security import generate_password_hash,check_password_hash
from http import HTTPStatus
from flask_jwt_extended import (create_access_token,set_refresh_cookies,
create_refresh_token,jwt_required,get_jwt_identity,set_access_cookies,get_jwt)
from werkzeug.exceptions import Conflict,BadRequest
from datetime import datetime, timedelta, timezone

def auth_login(request):
    data=request.get_json()
    email=data.get('name')
    password=data.get('password')
    user = email



    if (user == "onkar") and (password=="123"):
        access_token=create_access_token(identity=user)
        refresh_token=create_refresh_token(identity=user)

        response = jsonify(
            acccess_token=access_token,
            refresh_token=refresh_token
        )
        set_access_cookies(response, access_token)
        set_refresh_cookies(response, refresh_token)
        return response


def auth_refresh_token(request):
    exp_timestamp = get_jwt()["exp"]
    now = datetime.now(timezone.utc)
    target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
    if target_timestamp > exp_timestamp:
        name=get_jwt_identity()
        access_token=create_access_token(identity=name)
        response = jsonify({"msg": "login successful"})
        set_access_cookies(response, access_token)
        print(name)
    else: return jsonify({"msg": "not experied yet"})
    
    
    return {'access_token':access_token}
